using Photon.Pun;
using Photon.Realtime;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class PlayerController : MonoBehaviourPunCallbacks
{
    [SerializeField]
    private float _moveSpeed = 5f;
    [SerializeField]
    private float _rotationSpeed = 60f;

    public string Nickname
    {
        get
        {
            return _nicknameText.text;
        }
        
        set
        {
            _nicknameText.text = value;
        }
    }

    private Rigidbody _rigid;
    private TextMeshProUGUI _nicknameText;

    void Awake()
    {
        _rigid = GetComponent<Rigidbody>();
        _nicknameText = GetComponentInChildren<TextMeshProUGUI>();

        if(photonView.IsMine)
        {
            Camera.main.transform.parent = transform;
            Camera.main.transform.localPosition = new Vector3(0f, 4f, -10f);
            Camera.main.transform.localRotation = Quaternion.identity;
        }
    }

    void FixedUpdate()
    {
        if(false == photonView.IsMine)
        {
            return;
        }

        // �̵�
        float inputForward = Input.GetAxis("Vertical");

        Vector3 deltaPosition = inputForward * _moveSpeed * Time.fixedDeltaTime * transform.forward;
        _rigid.MovePosition(_rigid.position + deltaPosition);

        // ȸ��
        float inputRight = Input.GetAxis("Horizontal");
        float deltaRotationY = inputRight * _rotationSpeed * Time.fixedDeltaTime;
        _rigid.MoveRotation(_rigid.rotation * Quaternion.Euler(0f, deltaRotationY, 0f));
    }

    [PunRPC]
    public void SetNickname(string nickname)
    {
        Nickname = nickname;
    }

    public override void OnPlayerEnteredRoom(Player newPlayer)
    {
        photonView.RPC("SetNickname", newPlayer, Nickname);
    }
}
